namespace Unity.VisualScripting
{
    public enum Edge
    {
        Top,
        Bottom,
        Left,
        Right
    }
}
