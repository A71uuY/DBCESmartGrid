namespace Unity.VisualScripting
{
    public enum SidebarAnchor
    {
        Left,
        Right
    }
}
