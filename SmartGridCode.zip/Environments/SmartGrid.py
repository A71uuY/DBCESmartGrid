import numpy as np
import gym
from gym import spaces
import pickle as pkl
import random
import copy
import itertools
from itertools import product


class SmartGrid(gym.Env):
    def __init__(self, n_agents=2, n_links=3, mod_rew=False,normalize_obs=True,dist="Uniform",protect_p=1) -> None:
        # Now we assume there is only one attacker
        if mod_rew == True:
            raise NotImplementedError
        super().__init__()
        self.env_name = 'Grid'
        self.num_agents = n_agents 
        self.dist=dist
        self.protect_success_p = protect_p
        self.agents_state = [-1] * self.num_agents  # 加
        self.cumulative_rewards = [0] * self.num_agents
        self.num_links = n_links
        self.s = [0] * self.num_agents
        self.punishment_reward = 3
        self.all_states = None  
        self.all_states = self.get_all_states()  
        self.default_reward = 0 
        # self.collect_reward = 1
        self.action_space = self.num_links+1 # 0: stay, 1 to nlinks: Activate / Deactivate a link protection, or stay
        self.joint_act_nums = np.power(self.action_space, self.num_agents) 
        # observation space should be agent location + package location + agent energy
        self.observation_space = self.num_links  
        # self.current_protection = [0 for _ in range(self.num_agents)] # 0 for nothing
        self.mod_rew=mod_rew
        self.normalize_obs=normalize_obs
        self.ori_idx = None
        self.alter_idx = None
        self.init_act_idx()
        self.all_jacts = [i for i in self.joint_acts()] 
        self.possible_states = len(self.all_states)
        self.transition_matrix = self.initialize_trans_prob_dict_sas()  # YES  #
        self.bad_states = self.init_bad_states()
        self.com2_states = self.com2_prot_states()
        self.com3_states = self.com3_prot_states()
        self.check_transition_prob()
        self.reward_table = self.init_reward_tables()
        self.balance_states = self.init_balance_states()
        

    def step(self, act): 
        done = False

        cyber_attack = self.perform_attack(self.dist)
        reward = self.cal_reward(self.s,act,cyber_attack) # We assume attack and protection happen simultaneously

        new_state = self.get_transition(self.s, act)
        obs = new_state
        self.s = new_state
        info = {"attack_state":cyber_attack,"new_state":obs,"defended_by":[]}
        for i in range(self.num_agents):
            if new_state[i] == cyber_attack:
                info["defended_by"].append(i)
        return obs, reward, done, info

    # def step_sample(self, act): 
    #     # return the attacked link as well. return the (oldstates, attacked_state)
    #     # This function is only used for sampling trajectories.
    #     done = False
    #     cyber_attack = self.perform_attack(self.dist)
    #     reward = self.cal_reward(self.s,act,cyber_attack) # We assume attack and protection happen simultaneously
    #     new_state = self.get_transition(self.s, act)
    #     obs = new_state
    #     self.s = new_state
    #     info = {"attack_state":cyber_attack,"new_state":obs,"defended_by":[]}
    #     for i in range(self.num_agents):
    #         if new_state[i] == cyber_attack:
    #             info["defended_by"].append(i)
    #     return obs, reward, done, info

    def get_transition(self, from_state, actions):
        to_state = [0]*self.num_agents

        for i in range(self.num_agents):
            a = actions[i]
            if a == 0: # Stay
                to_state[i] = from_state[i]
            else:
                if from_state[i] == 0:
                    to_state[i] = a # Protect this link
                else:
                    to_state[i] = 0 # Deactivate
        return to_state

    def perform_attack(self,dist="Uniform"):
        if dist == "Uniform":
            link = np.random.choice(list(range(1,self.num_links+1)))
        else: #TODO: power-law
            pass
        return link

    # def attack_distribution(self, distribution="uni"):
    #     # distribution = "pld"

    #     # 随机生产一个数组表示哪些节点被攻击
    #     # 测试均匀分布 和 幂律分布
    #     attack_array = []
    #     if distribution == "uni":
    #         # attack_array = [random.randint(0, 1) for _ in range(self.num_links)]
    #         attack_array = [0.5] * self.num_links
    #     elif distribution == "pld":
    #         # alpha = 2
    #         # samples = np.random.power(alpha - 1, size=10)
    #         # rankings = np.argsort(-samples) + 1
    #         # attack_array = (np.random.rand(len(rankings)) < rankings).astype(int)
    #         a = 0.7
    #         k = 2  # 幂律分布的指数
    #         attack_array = [a / (i + 1) ** k for i in range(self.num_links)]

    #     return attack_array

    def reset(self):

        # Random Initialization
        # for i in range(self.num_agents):
        #     s_id = np.random.choice(list(range(1,self.num_links+1))) # Randomly protect one link
        #     self.s[i] = s_id
        # self.cumulative_rewards = [0] * self.num_agents
        # Fixed Initialization
        self.s = [np.random.choice([i for i in range(1,self.num_links+1)]) for _ in range(self.num_agents)]
        return self.s

    def is_state_danger(self, state):
        return state.count(1) == 0 # Critical institution (1) is not under protection

    def joint_acts(self):
        return product(range(self.num_links + 1), repeat=self.num_agents)

    def get_ori_idx(self, player):
        return self.ori_idx[player]

    def get_alter_idx(self, player):
        return self.alter_idx[player]

    def init_act_idx(self):
        # each agent has 2 actions 0,1
        # Initialize original actions idx lists and alternative actions idx lists.
        # Store as multi-dimensional lists
        # Can be called by index that represents agents
        all_joint_acts = [list(i) for i in self.joint_acts()
                          ]  # get all joint actions as a list to read index
        ## Initialize original and alternative action index lists
        self.ori_idx = [[[] for _ in range(self.action_space)] for _ in range(self.num_agents)
                        ]  #  actions * n agents
        # 2 alter actions * 3 actions * n agents

        ## Initialize ori_idx list
        for i in range(len(all_joint_acts)):
            joint_act = all_joint_acts[
                i]  # joint_act should be a list with n elements represents actions
            for j in range(len(joint_act)):  # agent j
                act = joint_act[j]  # action of agent j
                self.ori_idx[j][act].append(
                    i)  # in joint_action i, agent j perform action act
        ## Initialize alter_idx list
        self.alter_idx = [[
            copy.deepcopy(self.ori_idx[i]) for _ in range(self.action_space)
        ] for i in range(self.num_agents)]
        for i in range(len(all_joint_acts)):
            joint_act = all_joint_acts[
                i]  # joint_act should be a list with n elements represents actions
            for j in range(len(joint_act)):  # agent j
                act = joint_act[j]  # action of agent j
                for grp in self.alter_idx[j][act]:
                    if i in grp:
                        grp.remove(i)
        ## Remove empty list
        for agent_l in self.alter_idx:
            for ori_act_l in agent_l:
                for alter_act_l in ori_act_l:
                    if len(alter_act_l) == 0:
                        ori_act_l.remove(alter_act_l)

        return 1

    def eval_reset(self, agent_init_pos):
        return self.reset()

    def get_all_states(self):
        if self.all_states != None:
            return self.all_states
        else:
            all_states = []
            for n in product(list(range(0,self.num_links+1)),repeat=self.num_agents):
                all_states.append(list(n))
        self.all_states = all_states

        return self.all_states

    def initialize_trans_prob_dict_sas(self):
        result_mat = []
        for from_state in self.get_all_states():  # Which state we come from
            row_result = []
            for j_act in self.joint_acts(): # action
                act_result = []
                for to_state in self.get_all_states():  # Which state to go to
                    prob = self.transition_prob(np.array(from_state), np.array(to_state), np.array(j_act))
                    act_result.append(prob)
                row_result.append(act_result)
            result_mat.append(row_result)
        return result_mat  # form is from, aciton, to
    
    # def transition_prob(self, from_state, to_state, joint_act):  # 主要要改的是这里，概率状态转移函数
    #     prob = 0
    #     if np.array_equal(to_state, self.get_transition(from_state, joint_act)):
    #         prob = 1
    #     else:
    #         prob = 0

    #     return prob
    
    def transition_prob(self, from_state, to_state, joint_act):  # Deterministic Transition
        prob = 0
        # Check the resulting state
        new_state = self.get_transition(from_state,joint_act)
        if np.array_equal(to_state, new_state):
            prob = 1
        else:
            prob = 0

        return prob

    def check_transition_prob(self):
        all_v = []
        for state in range(len(self.transition_matrix)):
            for action in range(len(self.transition_matrix[state])):
                out_prob = sum(self.transition_matrix[state][action])
                all_v.append(out_prob)
                if int(out_prob)!= 1:
                    print(out_prob)
                    print(self.all_states[state])
                    print(self.all_jacts[action])
                    print(self.transition_matrix[state][action])
                    return 0
        print(min(all_v)==max(all_v)==1)
        return all_v

    def vec_to_ind(self,obs):
        # Observation to id
        return self.all_states.index(obs)

    def ind_to_act(self, ind):
        return self.all_jacts[ind]

    def jointact_to_ind(self,jact):
        return self.all_jacts.index(jact)

    def init_bad_states(self):
        bad_ids = []
        for i in range(len(self.get_all_states())):
            state = self.get_all_states()[i]
            if self.is_state_danger(state):
                bad_ids.append(i)
        return bad_ids

    def com2_prot_states(self):
        bad_ids = []
        for i in range(len(self.get_all_states())):
            state = self.get_all_states()[i]
            if state.count(2) >= 1:
                bad_ids.append(i)
        return bad_ids
    
    def com3_prot_states(self):
        bad_ids = []
        for i in range(len(self.get_all_states())):
            state = self.get_all_states()[i]
            if state.count(3) >= 1:
                bad_ids.append(i)
        return bad_ids

    def cal_reward(self, state, act, attack):
        reward = [0 for _ in range(self.num_agents)]
        after_state = self.get_transition(state,act)
        
        for i in range(self.num_agents):
            if sum(state) == 0: # No protection
                reward[i] -= self.punishment_reward
            protect = after_state[i]
            if protect == attack:
                if np.random.rand() < self.protect_success_p: # We assume independent defense now
                    reward[i] += 1
        return reward
    
    def init_reward_tables(self):
        rewards = np.zeros(shape=(self.possible_states,self.joint_act_nums,self.num_agents))
        rewards += self.default_reward*self.num_agents
        s_num = 0
        for state in self.get_all_states():
            a_num = 0
            for act in self.joint_acts():
                after_state = self.get_transition(state,act)
                for i in range(self.num_agents):
                    protect = after_state[i]
                    if protect != 0:
                        rewards[s_num][a_num][i] = 1/self.num_links
                if sum(state) == 0:
                    rewards[s_num][a_num] -= self.punishment_reward
                a_num += 1
            s_num += 1
        return rewards

    def init_balance_states(self):
        """
        return 2 lists of states, for balancing target
        Suppose we balance 2 and 3
        """
        list_2, list_3 = [],[]
        for i in range(len(self.all_states)):
            s = self.all_states[i]
            if 2 in s or 1 in s:
                list_2.append(i)
            if 3 in s:
                list_3.append(i)
        # return np.array([[1], [2]])
        return np.array([list_2,list_3])

    def render(self):
        print(self.s)


if __name__ == '__main__':
    env = SmartGrid()
    env.reset()
    env.render()
    #env.check_transition_prob()
    obs, reward, done, info = None, None, None, None


    for step in range(100):
        aid = np.random.choice(list(range(len(env.all_jacts))))
        act = list(env.all_jacts[aid])
        # print(act)
        #act = np.repeat(0,env.num_agents)
        obs, reward, done, info = env.step(act)
        # print(env.agents_state)
        # env.render()
        # print()
