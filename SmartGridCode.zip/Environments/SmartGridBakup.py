import numpy as np
import gym
from gym import spaces
import pickle as pkl
import random
import copy
import itertools
from itertools import product


class SmartGrid(gym.Env):
    def __init__(self, n_agents=2, mod_rew=False,normalize_obs=True) -> None:
        super().__init__()
        self.env_name = 'Grid'  # YES √
        self.num_agents = n_agents  # YES √ # 暂时不改这句
        self.agents_state = [-1] * self.num_agents  # 加
        self.cumulative_rewards = [0] * self.num_agents

        self.links_num = 3
        self.s = [0] * self.links_num  # YES  # 研究研究怎么改

        self.punishment_reward = 1.5

        self.all_states = None  # YES √  # 这句看起来可以去掉？
        self.all_states = self.get_all_states()  # YES √

        self.default_reward = 0
        # self.collect_reward = 1
        self.action_space = self.links_num + 2  # 2 movements  # YES √ # 不需要按照gym的格式来吗？
        self.joint_act_nums = np.power(self.action_space, self.num_agents)  # YES √
        # observation space should be agent location + package location + agent energy
        self.observation_space = self.links_num  # YES √ # 不需要按照gym的格式来吗？

        self.mod_rew=mod_rew
        self.normalize_obs=normalize_obs
        self.ori_idx = None
        self.alter_idx = None
        self.init_act_idx()
        self.all_jacts = [i for i in self.joint_acts()]  # YES  # 每个可能的联合行动，这句不知道需不需要改
        self.possible_states = len(self.all_states)
        self.transition_matrix = self.initialize_trans_prob_dict_sas()  # YES  #
        self.bad_states = self.init_bad_states()
        self.check_transition_prob()
        self.reward_table = self.init_reward_tables()
        self.balance_states = self.init_balance_states()

    def step(self, act):  # YES
        done = False

        new_state = self.get_transition(self.s, act)

        obs = new_state
        self.s = new_state

        reward = self.get_reward(act)

        return obs, reward, done, {}

    def get_transition(self, from_state, actions):
        to_state = copy.copy(from_state)
        # 更新状态 # 重新分配被守护的线
        def is_protect_command(action):
            return action < self.links_num

        def is_retract_defence(action):
            return action == self.links_num

        for agent_index in range(len(actions)):
            if is_protect_command(actions[agent_index]):
                if self.agents_state[agent_index] == -1:
                    self.agents_state[agent_index] = actions[agent_index]
                    to_state[actions[agent_index]] += 1
            elif is_retract_defence(actions[agent_index]):
                if self.agents_state[agent_index] != -1:
                    to_state[self.agents_state[agent_index]] -= 1
                    self.agents_state[agent_index] = -1
            else:
                pass

        return to_state

    def get_reward(self, action):
        reward = np.zeros(self.num_agents, dtype=np.float32)

        attack_array = self.attack_distribution()

        for i in range(self.links_num):
            if np.random.rand() < attack_array[i]:  # 不同分布的概率被攻击
                defenders = self.s[i]
                if defenders > 0 and np.random.rand() > 0.5 ** defenders:
                    reward[action == i] -= 1  # 防御成功
                else:
                    reward += 1  # 防御失败

        self.cumulative_rewards += reward

        return reward

    def attack_distribution(self, distribution="uni"):
        # distribution = "pld"

        # 随机生产一个数组表示哪些节点被攻击
        # 测试均匀分布 和 幂律分布
        attack_array = []
        if distribution == "uni":
            # attack_array = [random.randint(0, 1) for _ in range(self.links_num)]
            attack_array = [0.5] * self.links_num
        elif distribution == "pld":
            # alpha = 2
            # samples = np.random.power(alpha - 1, size=10)
            # rankings = np.argsort(-samples) + 1
            # attack_array = (np.random.rand(len(rankings)) < rankings).astype(int)
            a = 0.7
            k = 2  # 幂律分布的指数
            attack_array = [a / (i + 1) ** k for i in range(self.links_num)]

        return attack_array

    def reset(self):
        def assign_agents(guard_count, total_agents):
            # 初始化第二个数组，长度为Agent的总数，初始值为-1
            agent_positions = [-1] * total_agents

            agent_index = 0
            for exit_index, count in enumerate(guard_count):
                for _ in range(count):
                    # 只有当还有Agent可分配时，才分配Agent
                    if agent_index < total_agents:
                        agent_positions[agent_index] = exit_index
                        agent_index += 1
                    else:
                        break  # 如果所有Agent都已分配，则停止

            return agent_positions

        s_id = np.random.choice(list(range(self.possible_states)))
        self.s = list(self.all_states[s_id])
        self.agents_state = assign_agents(self.s, self.num_agents)

        return self.s

    def is_state_danger(self, state):
        return state == 3

    def joint_acts(self):
        return product(range(self.links_num + 2), repeat=self.num_agents)

    def get_ori_idx(self, player):
        return self.ori_idx[player]

    def get_alter_idx(self, player):
        return self.alter_idx[player]

    def init_act_idx(self):
        # each agent has 2 actions 0,1
        # Initialize original actions idx lists and alternative actions idx lists.
        # Store as multi-dimensional lists
        # Can be called by index that represents agents
        all_joint_acts = [list(i) for i in self.joint_acts()
                          ]  # get all joint actions as a list to read index
        ## Initialize original and alternative action index lists
        self.ori_idx = [[[] for _ in range(self.action_space)] for _ in range(self.num_agents)
                        ]  # 2 actions * n agents
        # 2 alter actions * 3 actions * n agents

        ## Initialize ori_idx list
        for i in range(len(all_joint_acts)):
            joint_act = all_joint_acts[
                i]  # joint_act should be a list with n elements represents actions
            for j in range(len(joint_act)):  # agent j
                act = joint_act[j]  # action of agent j
                self.ori_idx[j][act].append(
                    i)  # in joint_action i, agent j perform action act
        ## Initialize alter_idx list
        self.alter_idx = [[
            copy.deepcopy(self.ori_idx[i]) for _ in range(self.action_space)
        ] for i in range(self.num_agents)]
        for i in range(len(all_joint_acts)):
            joint_act = all_joint_acts[
                i]  # joint_act should be a list with n elements represents actions
            for j in range(len(joint_act)):  # agent j
                act = joint_act[j]  # action of agent j
                for grp in self.alter_idx[j][act]:
                    if i in grp:
                        grp.remove(i)
        ## Remove empty list
        for agent_l in self.alter_idx:
            for ori_act_l in agent_l:
                for alter_act_l in ori_act_l:
                    if len(alter_act_l) == 0:
                        ori_act_l.remove(alter_act_l)

        return 1

    def eval_reset(self, agent_init_pos):
        return self.reset()

    def get_all_states(self):
        if self.all_states != None:
            return self.all_states
        else:
            self.all_states = []
            for comb in itertools.product(range(self.num_agents + 1), repeat=self.links_num):
                if sum(comb) <= self.num_agents:
                    self.all_states.append(comb)

        return self.all_states

    def initialize_trans_prob_dict_sas(self):
        result_mat = []
        for from_state in self.get_all_states():  # Which state we come from
            row_result = []
            for j_act in self.joint_acts(): # action
                act_result = []
                for to_state in self.get_all_states():  # Which state to go to
                    prob = self.transition_prob(np.array(from_state), np.array(to_state), np.array(j_act))
                    act_result.append(prob)
                row_result.append(act_result)
            result_mat.append(row_result)
        return result_mat  # form is from, aciton, to
    
    def transition_prob(self, from_state, to_state, joint_act):  # 主要要改的是这里，概率状态转移函数
        prob = 0
        if np.array_equal(to_state, self.get_transition(from_state, joint_act)):
            prob = 1
        else:
            prob = 0

        return prob

    def check_transition_prob(self):
        all_v = []
        for state in range(len(self.transition_matrix)):
            for action in range(len(self.transition_matrix[state])):
                out_prob = sum(self.transition_matrix[state][action])
                all_v.append(out_prob)
                if int(out_prob)!= 1:
                    print(out_prob)
                    print(self.all_states[state])
                    print(self.all_jacts[action])
                    print(self.transition_matrix[state][action])
                    return 0
        print(min(all_v)==max(all_v)==1)
        return all_v

    def vec_to_ind(self,obs):
        # Observation to id
        return self.all_states.index(tuple(obs))
    def ind_to_act(self, ind):
        return self.all_jacts[ind]
    def jointact_to_ind(self,jact):
        return self.all_jacts.index(jact)

    def init_bad_states(self):
        bad_ids = []
        for i in range(len(self.get_all_states())):
            state = self.get_all_states()[i]
            if self.is_state_danger(state):
                bad_ids.append(i)
        return bad_ids

    def cal_reward(self, state, act):
        reward = [0,0]
        if self.mod_rew:
            if self.is_state_danger(state):
                reward =[-self.punishment_reward,-self.punishment_reward]
        if state == 0: # Compare act
            reward = [0,0]
        elif state == 1:
            reward = [0,0]
        elif state == 2:  # Guess
            reward_id = np.random.choice([0,1])
            reward = [[-0.5,0.5],[0.5,-0.5]][reward_id]
            reward = [0,0]
        elif state == 3: # FooGame
            reward_id = np.random.choice([0,1])
            reward = [[-1,1],[1,-1]][reward_id]
        return reward
    def init_reward_tables(self):
        rewards = np.zeros(shape=(self.possible_states,self.joint_act_nums,self.num_agents))
        rewards += self.default_reward*self.num_agents
        s_num = 0
        for state in self.get_all_states():
            a_num = 0
            for act in self.joint_acts():
                rewards[s_num][a_num] = 0
                a_num += 1
            s_num += 1
        return rewards

    def init_balance_states(self):
        """
        return 2 lists of states, for balancing target
        """
        return np.array([[1], [2]])

    def render(self):
        print(self.s)


if __name__ == '__main__':
    env = SmartGrid()
    env.reset()
    env.render()
    #env.check_transition_prob()
    obs, reward, done, info = None, None, None, None
    for step in range(100):
        act = np.random.randint(0,env.links_num+2,env.num_agents)
        print(act)
        #act = np.repeat(0,env.num_agents)
        obs, reward, done, info = env.step(act)
        print(env.agents_state)
        env.render()
        print()
