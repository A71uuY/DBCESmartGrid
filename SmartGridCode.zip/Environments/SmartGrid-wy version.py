import gym
from gym import spaces
import numpy as np
import random
import pickle as pkl
import copy

import itertools
from itertools import product


class SmartGrid(gym.Env):
    def __init__(self, num_agents=2, mod_rew=False, normalize_obs=True) -> None:
        super().__init__()

        # 问题组成
        self.num_agents = num_agents
        self.agents_state = [-1] * self.num_agents
        self.links_num = 3

        # 定义动作空间和观测空间
        # 约定action是一个数组，每个值代表某个Agent愿意守护的边，Agent可以选择不变(num+1)或撤回守护(num+2)
        self.action_space = spaces.MultiDiscrete([self.links_num + 2] * num_agents)
        self.observation_space = spaces.Box(low=0, high=self.num_agents, shape=(self.links_num,), dtype=np.int32)

        self.cumulative_rewards = [0, 0]

        # 初始化状态
        self.state = None

    def step(self, action):
        # 更新状态 # 重新分配被守护的线
        # 加一轮
        self.action_change_state()

        reward = self.get_reward(action)

        # 检查是否完成
        done = False

        obs, reward, done, info = self.state, reward, done, {}
        return obs, reward, done, info

    def action_change_state(self):
        def is_protect_command(action):
            return action < self.links_num

        def is_retract_defence(action):
            return action == self.links_num

        for agent_index in range(len(action)):
            if is_protect_command(action[agent_index]):
                if self.agents_state[agent_index] == -1:
                    self.agents_state[agent_index] = action[agent_index]
                    self.state[action[agent_index]] += 1
            elif is_retract_defence(action[agent_index]):
                if self.agents_state[agent_index] != -1:
                    self.state[self.agents_state[agent_index]] -= 1
                    self.agents_state[agent_index] = -1
            else:
                pass

    def reset(self):
        self.state = np.zeros(self.links_num, dtype=np.int32)
        return self.state

    def attack_distribution(self, distribution="uni"):
        # distribution = "pld"

        # 随机生产一个数组表示哪些节点被攻击
        # 测试均匀分布 和 幂律分布
        attack_array = []
        if distribution == "uni":
            # attack_array = [random.randint(0, 1) for _ in range(self.links_num)]
            attack_array = [0.5] * self.links_num
        elif distribution == "pld":
            # alpha = 2
            # samples = np.random.power(alpha - 1, size=10)
            # rankings = np.argsort(-samples) + 1
            # attack_array = (np.random.rand(len(rankings)) < rankings).astype(int)
            a = 0.7
            k = 2  # 幂律分布的指数
            attack_array = [a / (i + 1) ** k for i in range(self.links_num)]

        return attack_array

    def get_reward(self, action):
        reward = np.zeros(self.num_agents, dtype=np.float32)
        for i in range(self.links_num):
            if np.random.rand() < 0.5:  # 50% 概率被攻击
                defenders = self.state[i]
                if defenders > 0 and np.random.rand() > 0.5 ** defenders:
                    reward[action == i] -= 1  # 防御成功
                else:
                    reward += 1  # 防御失败
        self.cumulative_rewards += reward

        return reward

    def render(self):
        print(self.state, reward)


if __name__ == '__main__':
    env = SmartGrid(num_agents=2)
    env.reset()
    # env.check_transition_prob()
    obs, reward, done, info = None, None, None, None
    for step in range(100):
        action = np.random.randint(0,3+2,env.num_agents)
        env.render()
        # act = np.repeat(0,env.num_agents)
        obs, reward, done, info = env.step(action)