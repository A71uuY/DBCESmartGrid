# Density-based Correlated Equilibrium
This repository contains the codes and demos of Density-based Correlated Equilibrium.

## Execution
See LP_main.py for running experiments.
e.g. main('DBCE','DBCE','Hunt','MDCE') to run DBCE approach on finding MDCE in Hunt environment.

## Demos
Visualization folder contains the resources and source file to generate animations.
